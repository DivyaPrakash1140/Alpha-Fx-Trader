import { CurrencyPair } from '../types/trading';
import { tradingEngine } from './tradingEngine';

class DataFeedService {
  private subscribers: ((data: CurrencyPair[]) => void)[] = [];
  private isRunning = false;
  private intervalId: NodeJS.Timeout | null = null;
  
  private currencyPairs: CurrencyPair[] = [
    {
      id: 'eurusd',
      symbol: 'EUR/USD',
      base: 'EUR',
      quote: 'USD',
      price: 1.0850,
      change: 0.0012,
      changePercent: 5.11,
      high24h: 1.0875,
      low24h: 1.0825,
      volume: 1250000,
      lastUpdate: new Date()
    },
    {
      id: 'gbpusd',
      symbol: 'GBP/USD',
      base: 'GBP',
      quote: 'USD',
      price: 1.2650,
      change: -0.0025,
      changePercent: -0.20,
      high24h: 1.2685,
      low24h: 1.2620,
      volume: 980000,
      lastUpdate: new Date()
    },
    {
      id: 'usdjpy',
      symbol: 'USD/JPY',
      base: 'USD',
      quote: 'JPY',
      price: 149.50,
      change: 0.35,
      changePercent: 0.23,
      high24h: 150.20,
      low24h: 148.90,
      volume: 2100000,
      lastUpdate: new Date()
    },
    {
      id: 'audusd',
      symbol: 'AUD/USD',
      base: 'AUD',
      quote: 'USD',
      price: 0.6750,
      change: 0.0008,
      changePercent: 0.12,
      high24h: 0.6765,
      low24h: 0.6735,
      volume: 750000,
      lastUpdate: new Date()
    },
    {
      id: 'usdcad',
      symbol: 'USD/CAD',
      base: 'USD',
      quote: 'CAD',
      price: 1.3550,
      change: -0.0015,
      changePercent: -0.11,
      high24h: 1.3580,
      low24h: 1.3525,
      volume: 620000,
      lastUpdate: new Date()
    }
  ];

  start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.intervalId = setInterval(() => {
      this.updatePrices();
      this.notifySubscribers();
    }, 1000); // Update every second
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
  }

  subscribe(callback: (data: CurrencyPair[]) => void) {
    this.subscribers.push(callback);
    
    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(callback);
      if (index > -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  private updatePrices() {
    this.currencyPairs.forEach(pair => {
      // Simulate realistic price movements
      const volatility = 0.0001; // 1 pip movement
      const randomMove = (Math.random() - 0.5) * volatility * 2;
      const oldPrice = pair.price;
      
      pair.price = Number((pair.price + randomMove).toFixed(4));
      pair.change = Number((pair.price - oldPrice).toFixed(4));
      pair.changePercent = Number(((pair.change / oldPrice) * 100).toFixed(2));
      pair.lastUpdate = new Date();
      
      // Update volume randomly
      pair.volume += Math.floor(Math.random() * 50000);
      
      // Update 24h high/low
      if (pair.price > pair.high24h) pair.high24h = pair.price;
      if (pair.price < pair.low24h) pair.low24h = pair.price;
      
      // Feed price to trading engine
      tradingEngine.addPriceData(pair.symbol, pair.price);
    });
  }

  private notifySubscribers() {
    this.subscribers.forEach(callback => callback([...this.currencyPairs]));
  }

  getCurrentPrices(): CurrencyPair[] {
    return [...this.currencyPairs];
  }

  getPairBySymbol(symbol: string): CurrencyPair | undefined {
    return this.currencyPairs.find(pair => pair.symbol === symbol);
  }
}

export const dataFeedService = new DataFeedService();